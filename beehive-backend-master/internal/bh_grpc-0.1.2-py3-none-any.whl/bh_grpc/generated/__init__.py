import os
import sys


# this is a trick to avoid issues with incorrect import statements generated
# by protoc. see 7-year-long discussion here:
# https://github.com/protocolbuffers/protobuf/issues/1491
sys.path.append(os.path.dirname(__file__))
