def method_name_to_service_name(method_name: str) -> str | None:
    split = method_name.split('/')

    if len(split) < 2:
        return None
    else:
        return method_name.split('/')[1]
