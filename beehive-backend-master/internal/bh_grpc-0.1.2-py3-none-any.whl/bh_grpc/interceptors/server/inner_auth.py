from typing import Any, Callable

import grpc
from grpc_interceptor.server import AsyncServerInterceptor

from . import method_name_to_service_name


AUTH_HEADER_KEY = 'authorization'
AUTH_HEADER_PREFIX = 'Bearer '


class InnerAuthValidationInterceptor(AsyncServerInterceptor):
    def __init__(
        self, allowed_tokens: list[str], anonymous_services: list[str] = []
    ) -> None:
        super().__init__()

        self.allowed_tokens = allowed_tokens
        self.anonymous_services = anonymous_services

    async def intercept(
        self,
        method: Callable,
        request_or_iterator: Any,
        context: grpc.ServicerContext,
        method_name: str,
    ) -> Any:
        valid = False

        service_name = method_name_to_service_name(method_name)
        if service_name and service_name in self.anonymous_services:
            valid = True
        else:
            authorization = [
                m[1] for m in context.invocation_metadata() if m[0] == AUTH_HEADER_KEY
            ]
            if authorization and authorization[0].startswith(AUTH_HEADER_PREFIX):
                token = authorization[0][len(AUTH_HEADER_PREFIX) :]
                if token in self.allowed_tokens:
                    valid = True

        if valid:
            response_or_iterator = method(request_or_iterator, context)

            if hasattr(response_or_iterator, '__await__'):
                return await response_or_iterator
            else:
                return response_or_iterator
        else:
            await context.abort(grpc.StatusCode.UNAUTHENTICATED)
