from datetime import datetime, timezone
import logging
from logging.handlers import RotatingFileHandler
import time
from typing import Any, Callable

import grpc
from grpc_interceptor.server import AsyncServerInterceptor

from . import method_name_to_service_name


class GrpcServerAccessLoggingInterceptor(AsyncServerInterceptor):
    def __init__(self, access_logfile: str, exempted_services: list[str] = []) -> None:
        super().__init__()

        # set up the access logger
        self.access_logger = logging.getLogger('grpc.server.access')
        self.access_logger.setLevel(logging.INFO)

        if access_logfile == '-':
            access_logger_handler = logging.StreamHandler()
        else:
            access_logger_handler = RotatingFileHandler(
                access_logfile, maxBytes=1024 * 1024 * 5, backupCount=3
            )

        access_logger_handler.setFormatter(logging.Formatter('%(message)s'))
        self.access_logger.addHandler(access_logger_handler)
        self.access_logger.propagate = False

        self.exempted_services = exempted_services

    async def intercept(
        self,
        method: Callable,
        request_or_iterator: Any,
        context: grpc.ServicerContext,
        method_name: str,
    ) -> Any:
        start_time = time.time()
        success = True

        try:
            # handle the request
            response_or_iterator = await method(request_or_iterator, context)
        except:
            success = False
            raise
        finally:
            if (
                not self.exempted_services
                or method_name_to_service_name(method_name)
                not in self.exempted_services
            ):
                # log the request
                remote_address = context.peer()
                start_time_str = datetime.fromtimestamp(
                    start_time, tz=timezone.utc
                ).strftime('%d/%b/%Y:%H:%M:%S %z')
                if success:
                    status_code_str = 'SUCCESS'
                else:
                    status_code = context.code()
                    status_code_str = status_code.name if status_code else 'UNKNOWN'
                elapsed_time = (time.time() - start_time) * 1000
                elapsed_time_str = (
                    f'{elapsed_time:.2f}'
                    if elapsed_time < 10.0
                    else f'{elapsed_time:.1f}'
                    if elapsed_time < 100.0
                    else f'{elapsed_time:.0f}'
                )
                user_agent = [
                    m[1] for m in context.invocation_metadata() if m[0] == 'user-agent'
                ]
                user_agent_str = user_agent[0] if user_agent else '-'

                # attempt to log in a similar format as gunicorn in our existing
                # rest services
                self.access_logger.info(
                    f'{remote_address} - ? - [{start_time_str}] {method_name} '
                    f'{status_code_str} {elapsed_time_str} "-" {user_agent_str}'
                )

        return response_or_iterator
