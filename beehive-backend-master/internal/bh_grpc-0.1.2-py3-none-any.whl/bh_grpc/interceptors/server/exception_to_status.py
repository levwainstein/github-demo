from typing import Any, Callable, NoReturn

import grpc
from grpc_interceptor.exception_to_status import AsyncExceptionToStatusInterceptor
from grpc_interceptor.exceptions import GrpcException


class AsyncExceptionToStatusNoDetailsInterceptor(AsyncExceptionToStatusInterceptor):
    async def handle_exception(
        self,
        ex: Exception,
        request_or_iterator: Any,
        context: grpc.aio.ServicerContext,
        method_name: str,
    ) -> NoReturn:
        """overriding this to avoid sending exception details in the response message"""
        if isinstance(ex, GrpcException):
            await context.abort(ex.status_code)
        elif not context.code():
            if self._status_on_unknown_exception is not None:
                await context.abort(self._status_on_unknown_exception)
        raise ex

    async def intercept(
        self,
        method: Callable,
        request_or_iterator: Any,
        context: grpc.aio.ServicerContext,
        method_name: str,
    ) -> Any:
        """
        overriding this to support non-coroutine methods such as the health
        service's Check
        """
        try:
            response_or_iterator = method(request_or_iterator, context)
            if not hasattr(response_or_iterator, '__aiter__'):
                if hasattr(response_or_iterator, '__await__'):
                    return await response_or_iterator
                else:
                    return response_or_iterator
        except Exception as ex:
            await self.handle_exception(ex, request_or_iterator, context, method_name)

        return self._generate_responses(
            request_or_iterator, context, method_name, response_or_iterator
        )
