from typing import Any, Callable

import grpc
from grpc_interceptor import ClientCallDetails, ClientInterceptor


class OutboundAuthInterceptor(ClientInterceptor):
    def __init__(self, outbound_token: str) -> None:
        super().__init__()

        self.outbound_token = outbound_token

    def intercept(
        self,
        method: Callable,
        request_or_iterator: Any,
        call_details: grpc.ClientCallDetails,
    ):
        new_details = ClientCallDetails(
            call_details.method,
            call_details.timeout,
            [('authorization', f'Bearer {self.outbound_token}')],
            call_details.credentials,
            call_details.wait_for_ready,
            call_details.compression,
        )

        return method(request_or_iterator, new_details)
